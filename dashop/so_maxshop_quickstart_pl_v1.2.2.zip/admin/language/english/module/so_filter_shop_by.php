<?php
// Heading
$_['heading_title']                = 'So Filter Shop By';
// Text
$_['text_module']                  = 'Modules';
$_['text_success']                 = 'Success: You have modified module Hello World!';
$_['text_title_content_module']    = 'Content Filter Shop By';
$_['button_save'] = 'Save';
$_['button_cancel'] = 'Cancel';
$_['text_edit']        = 'Edit So Filter Shop By Module';
$_['entry_name']       		= 'Module Name';
$_['entry_name_desc']       = 'Module must have a name';
$_['entry_status']     = 'Status';
$_['text_edit_content']     = 'For Fun';
?>